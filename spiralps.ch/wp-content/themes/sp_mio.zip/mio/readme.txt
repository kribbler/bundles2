
PLEASE BACKUP FIRST BEFORE UPDATING THE THEME OR FRAMEWORK!  ALSO PLEASE TEST THIS ON A STAGING/TEST SITE BEFORE DEPLOYING TO A LIVE SITE


Theme Instructions
=========================================================================================================================================

Wordpress e-Commerce plugin:
If you have not already, you can donwload the FREE copy of the WPEC plugin here -> http://wordpress.org/extend/plugins/wp-e-commerce/


Woocommerce plugin:
If you have not already, you can donwload the FREE copy of the Woocommerce plugin here -> http://wordpress.org/extend/plugins/woocommerce/


Basic Theme Installation:

    1. Download the theme zip file from your Splashing Pixels member dashboard to your computer.
    2. Log in to your WordPress Admin Panel (Dashboard)
    3. Click on the Appearance tab
    4. Click on Themes link
    5. Click on the Upload link on top
    6. Click on the Browse and select the zip file you downloaded
    7. Click on the Install Now button
    8. Now click on the Activate link
    9. Click on the Store link on the WP settings tab and navigate to Presentation tab
    10. On the right side, click on the button �Flush Theme Cache�
    11. Enjoy, your theme is now ready to go!
    
    OR the manual way:

    1. Unzip the theme folder
    2. Connect to your server with an FTP client program (more info about FTP below)
    3. With your FTP program navigate to the WordPress theme folder and upload your Splashing Pixels theme folder there.
    4. Now log-in into your WordPress
    5. Admin Panel (Dashboard)
    6. Click on the Appearance tab
    7. Click on the Themes link
    8. Click on the Activate link underneath the newly uploaded theme
    9. Click on the Store link on the WP settings tab and navigate to Presentation tab
    10. On the right side, click on the button �Flush Theme Cache�
    11. Enjoy, your theme is now ready to go!

For a more complete and comprehensive theme instructions including tips, please visit http://splashingpixels.com/forums/