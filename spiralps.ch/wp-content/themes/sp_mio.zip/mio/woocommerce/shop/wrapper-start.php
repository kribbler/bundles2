<?php
/**
 * Content Wrappers
 */
$id = ( get_option('template') === 'twentyeleven' ) ? 'primary' : 'container';
?>
<div id="<?php echo $id; ?>">
	<div id="content" role="main">