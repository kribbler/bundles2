<?php
/**
 * @package Techotronic
 * @subpackage All in one Favicon
 *
 * @since 4.0
 * @author Arne Franken
 *
 * Right column for settings page
 */
?>
<div class="postbox-container" style="width: 29%;">
<?php
  require_once 'sp-donations.php';
  require_once 'sp-donate-box.php';
  require_once 'sp-translation.php';
  ?>
</div>