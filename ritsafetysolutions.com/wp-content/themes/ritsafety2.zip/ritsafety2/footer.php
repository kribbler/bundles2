<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
		<div class="clear"></div><br /><br /><br />
	</div><!-- #main -->
  <img src="<?php bloginfo('template_url'); ?>/images/bottom-bar-bg.png" style=" float:left !important; display:block !important; margin:0 !important; padding:0 !important;" />
  

	<div id="footer" style=" margin: 30px 0px 20px 0px; text-align:center; font-family:Arial, Helvetica, sans-serif; font-size:12px; line-height:20px; color:#FFFFFF;">
		  
 			 &copy 2012 RIT Safety Solutions, LLC. 1900 Enterprise Parkway, Suite H Twinsburg, OH 44087 <br />
        Phone: 800-254-2990 (330-405-5444 Cleveland/Akron area) 
      
	 
	</div><!-- #footer -->

<?php wp_footer(); ?>
</body>
</html>