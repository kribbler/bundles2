vc-table-manager
================

Table management for Visual Composer
