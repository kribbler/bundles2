<?php

if (!defined('ABSPATH')) exit;

class sss_sidebars {
    public $js = array();
    public $sidebars = array();
    public $active = array();
    public $styles = array();
    public $styles_map = array();
    public $styles_borders = array();
    public $styles_radius = array('tab' => array(), 'drawer' => array());
    public $sides = array();
    public $anchors = array('left' => '', 'right' => '');
    public $opened = array('left' => '', 'right' => '');

    function __construct() {
        add_action('widgets_init', array(&$this, 'register'), 10000);

        if (!is_admin()) {
            add_action('wp', array(&$this, 'init'));
        }
    }

    public function id($sidebar) {
        return 'sss-sidebar-'.$sidebar->_id;
    }

    public function args($sidebar) {
        $args = apply_filters('sss_sidebar_registration_args', array(
            'class' => '',
            'before_widget' => '<li id="%1$s" class="widget %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h2 class="widget-title">',
            'after_title' => '</h2>'
        ), $sidebar);

        $args['name'] = $sidebar->_name;
        $args['description'] = $sidebar->_description;
        $args['id'] = $this->id($sidebar);

        return $args;
    }

    public function register() {
        foreach (smart_sss_core()->sidebars['sidebars'] as $raw) {
            $this->sidebars[$raw['_id']] = new sss_sidebar_core($raw);
            $this->sidebars[$raw['_id']]->_args = $this->args($this->sidebars[$raw['_id']]);

            register_sidebar($this->sidebars[$raw['_id']]->_args);
        }
    }

    public function init() {
        foreach ($this->sidebars as $id => $sidebar) {
            if ($sidebar->active()) {
                $this->active[] = $id;
                $this->styles[] = $sidebar->style;
            }
        }

        if (!empty($this->active)) {
            add_action('wp_enqueue_scripts', array(&$this, 'wp_enqueue_scripts'));
            add_action('wp_head', array(&$this, 'wp_head'), 1000);
            add_action('wp_footer', array(&$this, 'wp_footer_top'), 0);
            add_action('wp_footer', array(&$this, 'wp_footer_bottom'), 10000000);
        }
    }

    public function wp_head() {
        $this->styles = array_unique($this->styles);

        echo SSS_EOL.'<style type="text/css">'.SSS_EOL;
        echo '/* Smart Sidebars Slider */'.SSS_EOL;

        foreach ($this->styles as $code) {
            $id = substr($code, 4);
            $type = substr($code, 0, 3);

            if ($type != 'cst') {
                if ($type == 'dfl') {
                    $raw = smart_sss_core()->styles[$id];
                } else if ($type == 'stl') {
                    $raw = smart_sss_core()->get_style($id);
                }

                $style = new sss_style_core($raw);
                $this->styles_map[$code] = $style->_code;
                $this->styles_borders[$code] = $style->border_width();
                $this->styles_radius['tab'][$code] = $style->tabRound;
                $this->styles_radius['drawer'][$code] = $style->drawerRound;

                echo SSS_EOL.'/* '.$style->_name.' */'.SSS_EOL;
                echo $style->build();
                echo SSS_EOL;
            } else {
                $obj = smart_sss_core()->get_custom_style($id);

                $this->styles_map[$code] = $id;
                $this->styles_borders[$code] = $obj['border'];
            }
        }

        do_action('sss_embed_styles_css');

        echo SSS_EOL.'</style>'.SSS_EOL;
    }

    public function wp_footer_top() {
        $this->js = array();

        if (smart_sss_core()->get('auto_tab_positioning')) {
            $left = $right = smart_sss_core()->get('auto_tab_offset');
            $spacing = smart_sss_core()->get('auto_tab_spacing');

            foreach ($this->active as $id) {
                $sidebar = $this->sidebars[$id];

                if ($sidebar->openOnLoad && $this->opened[$sidebar->location] == '') {
                    $this->opened[$sidebar->location] = $id;
                }

                if ($this->anchors[$sidebar->location] == '') {
                    $this->anchors[$sidebar->location] = $sidebar->anchor;
                }

                if ($sidebar->location == 'left') {
                    $this->sides[$id] = $left;

                    $left+= $sidebar->get_height() + $spacing;
                } else if ($sidebar->location == 'right') {
                    $this->sides[$id] = $right;

                    $right+= $sidebar->get_height() + $spacing;
                }
            }
        }

        foreach ($this->active as $id) {
            $sidebar = $this->sidebars[$id];

            $offset = isset($this->sides[$id]) ? $this->sides[$id] : null;
            $anchor = $this->anchors[$sidebar->location] != '' ? $this->anchors[$sidebar->location] : null;
            $opened = $this->opened[$sidebar->location] != '' && $this->opened[$sidebar->location] == $id;

            $this->js[] = $sidebar->build_js(
                    $this->styles_map[$sidebar->style],
                    $this->styles_borders[$sidebar->style],
                    $this->styles_radius['tab'][$sidebar->style],
                    $this->styles_radius['drawer'][$sidebar->style],
                    $offset, $anchor, $opened
            );

            $sidebar->build_html();
        }
    }

    public function wp_footer_bottom() {
        echo SSS_EOL.'<script type="text/javascript">'.SSS_EOL;
        echo 'jQuery(document).ready(function() {'.SSS_EOL;

        do_action('sss_embed_scripts_before');

        echo join(SSS_EOL, $this->js);

        do_action('sss_embed_scripts_after');

        echo '});'.SSS_EOL;
        echo '</script>'.SSS_EOL;
    }

    public function wp_enqueue_scripts() {
        if (smart_sss_core()->get('load_fontawesome')) {
            wp_enqueue_style('sss-fontawesome', '//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css');
        }

        wp_enqueue_style('sss-scroller', SSS_URL.'css/jquery.nanoscroller.min.css', array(), SMART_SIDEBARS_SLIDER);
        wp_enqueue_style('sss-drawer', SSS_URL.'css/drawer.core.min.css', array('sss-scroller'), SMART_SIDEBARS_SLIDER);
        wp_enqueue_style('sss-sidebars', SSS_URL.'css/sidebars.css', array('sss-drawer'), SMART_SIDEBARS_SLIDER);

        wp_enqueue_script('sss-easing', SSS_URL.'js/jquery.easing.min.js', array('jquery'), SMART_SIDEBARS_SLIDER, true);
        wp_enqueue_script('sss-scroller', SSS_URL.'js/jquery.nanoscroller.min.js', array('jquery'), SMART_SIDEBARS_SLIDER, true);
        wp_enqueue_script('sss-drawer', SSS_URL.'js/drawer.core.min.js', array('jquery', 'sss-easing', 'sss-scroller'), SMART_SIDEBARS_SLIDER, true);
    }
}

global $sss_sidebars_obj;
$sss_sidebars_obj = new sss_sidebars();

function sss_sidebars() {
    global $sss_sidebars_obj;
    return $sss_sidebars_obj;
}

?>