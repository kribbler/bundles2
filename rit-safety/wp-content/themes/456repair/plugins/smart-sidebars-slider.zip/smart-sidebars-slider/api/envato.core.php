<?php

/*
Name:    Smart Envato API: Core
Version: 2.8
Author:  Milan Petrovic
Email:   milan@gdragon.info
Website: http://www.dev4press.com/

== Copyright ==
Copyright 2008 - 2014 Milan Petrovic (email: milan@gdragon.info)
*/

if (!defined('ABSPATH')) exit;

if (!defined('SMART_ENVATO_API_USER_AGENT')) {
    define('SMART_ENVATO_API_USER_AGENT', true);
}

if (!defined('SMART_ENVATO_API_CACHE')) {
    define('SMART_ENVATO_API_CACHE', true);
}

if (!class_exists('smart_envato_storage')) {
    abstract class smart_envato_storage {
        function __construct() {}

        abstract public function get($name);
        abstract public function set($name, $value, $ttl = 0);
        abstract public function delete($name);

        abstract public function clear($base);
    }
}

if (!class_exists('smart_envato_api')) {
    abstract class smart_envato_api {
        private $storage = false;

        public $user_agent_string = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 SmartEnvatoAPI/2.8';

        public $marketplaces = array(
            'themeforest' => 'ThemeForest',
            'graphicriver' => 'GraphicRiver',
            'videohive' => 'VideoHive',
            'audiojungle' => 'AudioJungle',
            'codecanyon' => 'CodeCanyon',
            'activeden' => 'ActiveDen',
            '3docean' => '3DOcean',
            'photodune' => 'PhotoDune'
        );

        public $categories = array(
            'raw' => array(),
            'list' => array(),
        );

        public $base_url = '';
        public $sets = array(
            'public' => array(),
            'private' => array()
        );

        public $store = 'transient';
        public $cache = true;
        public $normalize = false;
        public $user_agent = false;
        public $curl = true;

        public $site = 'codecanyon';
        public $usr = '';
        public $key = '';
        public $ref = '';

        public $version = '';

        public function __construct($site = '', $usr = '', $key = '', $ref = '') {
            if (!function_exists('curl_init')) {
                $this->curl = false;
            }

            $this->user_agent = SMART_ENVATO_API_USER_AGENT;
            $this->cache = SMART_ENVATO_API_CACHE;

            if ($this->store != '') {
                require_once('storage/store.'.$this->store.'.php');

                $storage_class = 'smart_envato_store_'.$this->store;
                $this->storage = new $storage_class();
            }
            
            $this->setup($site, $usr, $key, $ref);
        }

        public function setup($site = '', $usr = '', $key = '', $ref = '') {
            $this->set_site($site);
            $this->set_usr($usr);
            $this->set_key($key);
            $this->set_ref($ref);
        }

        public function run_public($set, $site = '', $args = array(), $ttl = 0, $use_cache = true) {
            if (!$this->curl) {
                return new WP_Error('curl_missing', 'PHP extension CURL is required.');
            }

            $url = $this->url_public($set, $site, $args);
            $name = $this->get_storage_key_base().md5($url);

            $ttl = $this->get_ttl('public', $set, $ttl);

            return $this->_fetch($url, $name, $set, $ttl, $use_cache);
        }

        public function run_private($set, $usr = '', $key = '', $args = array(), $ttl = 0, $use_cache = true) {
            if (!$this->curl) {
                return new WP_Error('curl_missing', 'PHP extension CURL is required.');
            }

            $url = $this->url_private($set, $usr, $key, $args);
            $name = $this->get_storage_key_base().md5($url);

            $ttl = $this->get_ttl('private', $set, $ttl);

            return $this->_fetch($url, $name, $set, $ttl, $use_cache);
        }

        public function envato_categories($site, $return = 'list', $ttl = 0, $use_cache = true) {
            if ($site != '') {
                if (!isset($this->categories[$return][$site])) {
                    $this->_prepare_categories($site, $ttl, $use_cache);
                }

                return $this->categories[$return][$site];
            } else {
                if (empty($this->categories[$return])) {
                    foreach (array_keys($this->marketplaces) as $market) {
                        $this->_prepare_categories($market, $ttl, $use_cache);
                    }
                }

                return $this->categories[$return];
            }
        }

        public function envato_item($id, $ttl = 0, $use_cache = true) {
            $results = $this->run_public('item', '', array('id' => $id), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->item;
            }

            return $results;
        }

        public function envato_collection($id, $ttl = 0, $use_cache = true) {
            $results = $this->run_public('collection', '', array('id' => $id), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->collection;
            }

            return $results;
        }

        public function envato_user($user, $ttl = 0, $use_cache = true) {
            $results = $this->run_public('user', '', array('user' => $user), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->user;
            }

            return $results;
        }
        
        public function envato_popular($site = '', $ttl = 0, $use_cache = true) {
            $results = $this->run_public('popular', $site, array(), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->popular;
            }

            return $results;
        }

        public function envato_features($site = '', $ttl = 0, $use_cache = true) {
            $results = $this->run_public('features', $site, array(), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->features;
            }

            return $results;
        }

        public function envato_search($query, $site = '', $categories = array(), $ttl = 0, $use_cache = true) {
            $cats = array();

            foreach ($categories as $cat) {
                $cats[] = str_replace(' ', '-', strtolower($cat));
            }

            $results = $this->run_public('search', $site, array('category' => join('%2f', $cats), 'search' => $query), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->search;

                if (!$this->normalize) {
                    $results = $this->_normalize_search_results($results);
                }
            }

            return $results;
        }

        public function envato_verify_purchase($purchase_code, $usr = '', $key = '', $ttl = 0, $use_cache = true) {
            $results = $this->run_private('verify-purchase', $usr, $key, array('id' => $purchase_code), $ttl, $use_cache);

            if (!is_wp_error($results)) {
                $results = $results->{'verify-purchase'};
            }

            return $results;
        }

        public function url_add_referer($url, $ref = '') {
            $ref = $ref == '' ? $this->get_ref() : $ref;

            if (trim($ref) != '') {
                return $url.'?ref='.trim($ref);
            } else {
                return $url;
            }
        }

        public function url_marketplace($market) {
            if (isset($this->marketplaces[$market])) {
                return 'http://'.$market.'.net';
            } else {
                return '';
            }
        }

        public function url_item($url, $ref = '') {
            return $this->url_add_referer($url, $ref);
        }

        public function url_user($user, $site = '', $ref = '') {
            $site = $site == '' ? $this->get_site() : $site;

            $url = 'http://'.$site.'.net/user/'.$user;

            return $this->url_add_referer($url, $ref);
        }

        public function enable_normalization() {
            $this->normalize = true;
        }

        public function disable_normalization() {
            $this->normalize = false;
        }

        public function enable_cache() {
            $this->cache = true;
        }

        public function disable_cache() {
            $this->cache = false;
        }

        public function set_site($site) {
            $this->site = $site;
        }

        public function set_usr($usr) {
            $this->usr = $usr;
        }

        public function set_key($key) {
            $this->key = $key;
        }

        public function set_ref($ref) {
            if ($ref != '') {
                $this->ref = $ref;
            } else {
                $this->ref = $this->usr;
            }
        }

        public function get_set($set, $type = 'public') {
            if (isset($this->sets[$type][$set])) {
                return $this->sets[$type][$set];
            } else {
                return null;
            }
        }

        public function get_site() {
            return $this->site;
        }

        public function get_usr() {
            return $this->usr;
        }

        public function get_key() {
            return $this->key;
        }

        public function get_ref() {
            return $this->ref;
        }

        public function get_version() {
            return $this->version;
        }

        public function get_storage_key_base() {
            return 'env_'.$this->version.'_';
        }

        public function get_ttl($scope, $set, $ttl) {
            $actual = 0;

            if (isset($this->sets[$scope][$set])) {
                $actual = $this->sets[$scope][$set]['ttl'];
            }

            return $ttl < $actual ? $actual : $ttl;
        }

        public function build_url($url, $ext, $set, $type, $args) {
            $data = $this->get_set($set, $type);
            $url.= $data['format'].'.'.$ext;
            $args['set'] = $set;

            preg_match_all('(%.+?%)', $data['format'], $matches, PREG_PATTERN_ORDER);

            if (!empty($matches[0])) {
                $tags = array_unique($matches[0]);

                foreach ($tags as $tag) {
                    $item = trim($tag, '%');
                    $value = isset($args[$item]) ? $args[$item] : '';
                    $url = str_replace($tag, $value, $url);
                }
            }

            return $url;
        }

        public function clear_cache() {
            if ($this->storage !== false) {
                $this->storage->clear($this->get_storage_key_base());
            }
        }

        private function _fetch($url, $name, $set, $ttl = 0, $use_cache = true) {
            if ($this->cache && $use_cache) {
                $data = $this->_from_cache($name);

                if ($data === false || $data === '') {
                    $data = $this->_load($url, $set, $ttl);

                    if (!is_wp_error($data)) {
                        $this->_to_cache($name, $data, $ttl);
                    }
                }
            } else {
                $data = $this->_load($url, $set, $ttl);
            }

            return $data;
        }

        private function _load($url, $set, $ttl) {
            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            if ($this->user_agent && $this->user_agent_string != '') {
                curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent_string);
            }

            $output = '';
            $data = curl_exec($ch);

            if ($data === false) {
                $output = new WP_Error('curl_error', curl_error($ch));
            } else {
                if ($data == '') {
                    $output = new WP_Error('envato_error', 'No data received.');
                } else {
                    $output = json_decode($data);

                    if (isset($output->error)) {
                        $output = new WP_Error($output->code, $output->error);
                    } else {
                        if ($this->normalize) {
                            $output = $this->_normalize_items($output, $set, $ttl);
                        }
                    }
                }
            }

            curl_close($ch);
            return $output;
        }

        private function _to_cache($name, $value, $ttl = 0) {
            $cached = apply_filters('smart_envato_api_to_cache', false, $name, $value, $ttl);

            if (!$cached) {
                if ($this->storage !== false) {
                    return $this->storage->set($name, $value, $ttl);
                } else {
                    return false;
                }
            } else {
                return $cached;
            }
        }

        private function _from_cache($name) {
            $cached = apply_filters('smart_envato_api_from_cache', false, $name);

            if (!$cached) {
                if ($this->storage !== false) {
                    return $this->storage->get($name);
                } else {
                    return false;
                }
            } else {
                return $cached;
            }
        }

        private function _delete_cache($name) {
            $cached = apply_filters('smart_envato_api_delete_cache', false, $name);

            if (!$cached) {
                if ($this->storage !== false) {
                    return $this->storage->delete($name);
                } else {
                    return false;
                }
            } else {
                return $cached;
            }
        }

        private function _prepare_categories($site, $ttl = 0, $use_cache = true) {
            $ttl = $this->get_ttl('public', 'number-of-files', $ttl);

            $files = $this->run_public('number-of-files', $site, array(), $ttl, $use_cache);

            $this->categories['raw'][$site] = array();
            $this->categories['list'][$site] = array();

            if (!is_wp_error($files)) {
                $files = $files->{'number-of-files'};

                foreach ($files as $cat) {
                    $cat->slug = end(explode('/', $cat->url));
                    $this->categories['raw'][$site][$cat->slug] = $cat;
                    $this->categories['list'][$site][$cat->slug] = $cat->category;
                }
            }
        }

        private function _normalize_items($output, $set, $ttl = 0) {
            $normalize = false;
            $scope = 'public';

            if (isset($this->sets['public'][$set])) {
                if (isset($this->sets['public'][$set]['normalize']) && $this->sets['public'][$set]['normalize']) {
                    $normalize = true;
                }
            } else if (isset($this->sets['private'][$set])) {
                $scope = 'private';

                if (isset($this->sets['private'][$set]['normalize']) && $this->sets['private'][$set]['normalize']) {
                    $normalize = true;
                }
            }

            if ($normalize) {
                $ttl = $this->get_ttl($scope, $set, $ttl);

                $result = new stdClass();
                $result->{$set} = array();

                foreach ($output->{$set} as $item) {
                    $url = $this->url_public('item', '', array('id' => $item->id));
                    $new = $this->_fetch($url, '', 'item', $ttl, false);

                    if (!is_wp_error($new)) {
                        $result->{$set}[] = $new->item;
                    }
                }

                return $result;
            } else {
                return $output;
            }
        }

        private function _normalize_search_results($results) {
            $return = array();

            foreach ($results as $item) {
                if ($item->type == 'item') {
                    unset($item->type);

                    if (isset($item->item_info) && !is_null($item->item_info)) {
                        foreach ($item->item_info as $key => $value) {
                            if (!isset($item->$key)) {
                                $item->$key = $value;
                            }
                        }

                        unset($item->item_info);
                    }

                    if (isset($item->description)) {
                        unset($item->description);
                    }
                }

                $return[] = $item;
            }

            return $return;
        }

        public function url_public($set, $site = '', $args = array()) {
            if ($set != 'search') {
                $args['site'] = $site == '' ? $this->get_site() : $site;
            } else {
                $args['site'] = $site;
            }

            return $this->build_url($this->base_url, 'json', $set, 'public', $args);
        }

        public function url_private($set, $usr = '', $key = '', $args = array()) {
            $args['user'] = $usr == '' ? $this->get_usr() : $usr;
            $args['api_key'] = $key == '' ? $this->get_key() : $key;

            return $this->build_url($this->base_url, 'json', $set, 'private', $args);
        }
    }
}

?>