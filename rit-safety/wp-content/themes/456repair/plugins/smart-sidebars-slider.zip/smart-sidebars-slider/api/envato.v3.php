<?php

/*
Name:    Smart Envato API: V3
Version: 2.8
Author:  Milan Petrovic
Email:   milan@gdragon.info
Website: http://www.dev4press.com/

== Copyright ==
Copyright 2008 - 2014 Milan Petrovic (email: milan@gdragon.info)
*/

if (!defined('ABSPATH')) exit;

require_once('envato.core.php');

if (!class_exists('smart_envato_api_v3')) {
    final class smart_envato_api_v3 extends smart_envato_api {
        private static $instance;

        public $base_url = 'http://marketplace.envato.com/api/v3/';
        public $sets = array(
            'public' => array(
                'blog-posts' => array('ttl' => 600, 'format' => '%set%:%site%'),
                'active-threads' => array('ttl' => 180, 'format' => '%set%:%site%'),
                'number-of-files' => array('ttl' => 3600, 'format' => '%set%:%site%'),
                'popular' => array('ttl' => 3600, 'format' => '%set%:%site%'),
                'releases' => array('ttl' => 300, 'format' => '%set%'),
                'thread-status' => array('ttl' => 180, 'format' => '%set%:%id%'),
                'collection' => array('ttl' => 180, 'format' => '%set%:%id%', 'normalize' => true),
                'features' => array('ttl' => 1, 'format' => '%set%:%site%'),
                'new-files' => array('ttl' => 3600, 'format' => '%set%:%site%,%category%', 'normalize' => true),
                'new-files-from-user' => array('ttl' => 900, 'format' => '%set%:%user%,%site%'),
                'random-new-files' => array('ttl' => 600, 'format' => '%set%:%site%', 'normalize' => true),
                'total-users' => array('ttl' => 3600, 'format' => '%set%'),
                'item' => array('ttl' => 3600, 'format' => '%set%:%id%'),
                'item-prices' => array('ttl' => 3600, 'format' => '%set%:%id%'),
                'search' => array('ttl' => 180, 'format' => '%set%:%site%,%category%,%search%', 'normalize' => true),
                'user' => array('ttl' => 180, 'format' => '%set%:%user%'),
                'user-items-by-site' => array('ttl' => 180, 'format' => '%set%:%user%,%site%')
            ),
            'private' => array(
                'vitals' => array('ttl' => 60, 'format' => '%user%/%api_key%/%set%'),
                'earnings-and-sales-by-month' => array('ttl' => 600, 'format' => '%user%/%api_key%/%set%'),
                'statement' => array('ttl' => 600, 'format' => '%user%/%api_key%/%set%'),
                'recent-sales' => array('ttl' => 300, 'format' => '%user%/%api_key%/%set%'),
                'account' => array('ttl' => 60, 'format' => '%user%/%api_key%/%set%'),
                'verify-purchase' => array('ttl' => 180, 'format' => '%user%/%api_key%/%set%:%id%'),
                'download-purchase' => array('ttl' => 180, 'format' => '%user%/%api_key%/%set%:%id%')
            )
        );

        public $version = 'v3';

        function __construct($site = '', $usr = '', $key = '', $ref = '') {
            parent::__construct($site, $usr, $key, $ref);
        }

        public static function instance() {
            if (!isset(self::$instance)) {
                self::$instance = new smart_envato_api_v3();
            }

            return self::$instance;
	}
    }

    function envato_api() {
        return smart_envato_api_v3::instance();
    }

    function envato_api_v3() {
        return smart_envato_api_v3::instance();
    }
}

?>